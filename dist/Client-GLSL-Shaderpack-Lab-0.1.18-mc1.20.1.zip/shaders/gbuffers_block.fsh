#version 120
#include "/lib/pass_textured_lit.fsh"
